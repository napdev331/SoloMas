package com.solomas1.solomas_new

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
