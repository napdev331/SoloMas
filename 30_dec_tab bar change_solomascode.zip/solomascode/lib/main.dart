import 'app_initializer.dart';
import 'helpers/pref_helper.dart';

Future<void> main() async {
  initializeApp();
}
