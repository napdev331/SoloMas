import 'package:flutter/cupertino.dart';

space({double? width, double? height}) {
  return SizedBox(
    height: height,
    width: width,
  );
}
