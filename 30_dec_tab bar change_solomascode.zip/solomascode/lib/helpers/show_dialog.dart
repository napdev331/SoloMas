import 'package:carousel_slider/carousel_controller.dart';
import 'package:flutter/material.dart';

import '../model/public_feeds_model.dart';
import '../model/user_profile_model.dart';
import 'feed_dialog.dart';

class ShowDialog {
  static showFeedDialog(
    BuildContext context, {
    List<PublicFeedList>? imgUrl,
    List<Photo>? photoList,
    int? indexSearch,
    int? indexPro,
    required bool isHome,
    CarouselController? controller,
  }) {
    showDialog(
        context: context,
        builder: (context) => FeedDialog(
              imgUrl: imgUrl,
              indexSearch: indexSearch,
              indexpro: indexPro,
              controller: controller,
              isHome: isHome,
              photoList: photoList,
            ));
  }
}
