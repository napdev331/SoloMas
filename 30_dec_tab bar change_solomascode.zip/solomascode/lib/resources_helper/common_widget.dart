import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../helpers/common_helper.dart';
import '../helpers/constants.dart';
import '../resources_helper/dimens.dart';

Widget roundButton(BuildContext context, {String? path, Function()? onTap}) {
  return InkWell(
      onTap: onTap,
      child:
          Image.asset(path!, width: CommonHelper(context).screenWidth * 0.09));
}

Widget searchBar() {
  return Container(
    margin: EdgeInsets.only(
        left: DimensHelper.sidesMargin,
        right: DimensHelper.sidesMargin,
        top: DimensHelper.sidesMargin),
    child: Card(
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(
              Radius.circular(DimensHelper.sidesMarginDouble))),
      child: Row(
        children: [
          Expanded(
              child: Container(
            padding: EdgeInsets.all(DimensHelper.searchBarMargin),
            margin: EdgeInsets.only(left: DimensHelper.sidesMargin),
            child: TextFormField(
              keyboardType: TextInputType.text,
              textInputAction: TextInputAction.search,
              maxLines: 1,
              minLines: 1,
              autofocus: false,
              onChanged: (String) {},
              inputFormatters: [
                FilteringTextInputFormatter.allow(RegExp("[a-zA-Z -]")),
                LengthLimitingTextInputFormatter(30),
              ],
              decoration: InputDecoration.collapsed(
                  hintText: 'Search here...',
                  hintStyle: TextStyle(
                    fontSize: Constants.FONT_MEDIUM,
                  )),
            ),
          )),
          Container(
            padding: EdgeInsets.only(
              left: DimensHelper.halfSides,
              right: DimensHelper.sidesMargin,
            ),
            child: Image.asset(
              'images/ic_lg_bag.png',
              height: 20,
              width: 20,
            ),
          ),
        ],
      ),
    ),
  );
}
