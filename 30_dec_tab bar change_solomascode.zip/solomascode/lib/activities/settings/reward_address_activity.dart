import 'dart:convert';
import 'dart:ui';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:solomas/blocs/settings/get_rewards_bloc.dart';
import 'package:solomas/helpers/common_helper.dart';
import 'package:solomas/helpers/constants.dart';
import 'package:solomas/helpers/pref_helper.dart';
import 'package:solomas/helpers/progress_indicator.dart';
import 'package:solomas/model/reward_items_model.dart';
import 'package:solomas/resources_helper/colors.dart';
import 'package:solomas/resources_helper/dimens.dart';
import 'package:solomas/widgets/btn_widget.dart';

import 'edit_reward_address_activity.dart';

class RewardAddressActivity extends StatefulWidget {
  final RewardItem? rewardItemDetails;

  final String? totalPoints;

  RewardAddressActivity({this.rewardItemDetails, this.totalPoints});

  @override
  State<StatefulWidget> createState() {
    return _RewardAddressState();
  }
}

class _RewardAddressState extends State<RewardAddressActivity> {
  CommonHelper? _commonHelper;

  bool _progressShow = false;

  GetRewardsBloc? _rewardsBloc;

  String balancePoints = "";

  var mineUserAddress;

  void _showProgress() {
    setState(() {
      _progressShow = true;
    });
  }

  void _hideProgress() {
    setState(() {
      _progressShow = false;
    });
  }

  @override
  void initState() {
    super.initState();

    PrefHelper.getUserAddress().then((onValue) {
      setState(() {
        var address = json.decode(onValue.toString());

        mineUserAddress = address;
      });
    });

    _rewardsBloc = GetRewardsBloc();

    balancePoints = (int.parse(widget.totalPoints.toString()).toInt() -
            widget.rewardItemDetails!.pricePoint!.toInt())
        .toString();
  }

  void _onContinueTap() {
    if (mineUserAddress['name'] == null) {
      showCupertinoModalPopup(
          context: context,
          builder: (BuildContext context) => _commonHelper!.successBottomSheet(
              "Add Address", "Please add pick up address to continue.", false));

      return;
    } else if (mineUserAddress['state'] == null) {
      showCupertinoModalPopup(
          context: context,
          builder: (BuildContext context) => _commonHelper!.successBottomSheet(
              "Add State", "Please add valid state to continue.", false));

      return;
    } else if (mineUserAddress['street'] == null) {
      showCupertinoModalPopup(
          context: context,
          builder: (BuildContext context) => _commonHelper!.successBottomSheet(
              "Add Street",
              "Please add valid street name to continue.",
              false));

      return;
    }

    _commonHelper?.isInternetAvailable().then((available) {
      if (available) {
        _showProgress();

        var addressDetails = json.encode({
          'name': mineUserAddress['name'] ?? "",
          'street': mineUserAddress['street'] ?? "",
          'city': mineUserAddress['city'] ?? "",
          'state': mineUserAddress['state'] ?? "",
          'phoneNumber': mineUserAddress['phoneNumber'] ?? "",
          'email': mineUserAddress['email'] ?? ""
        });

        var body = json.encode({
          "rewardItemId": widget.rewardItemDetails?.sId,
          "address": addressDetails.toString(),
        });

        PrefHelper.getAuthToken().then((authToken) {
          _rewardsBloc
              ?.buyRewardItem(body.toString(), authToken.toString())
              .then((onSuccess) {
            _hideProgress();

            showCupertinoModalPopup(
                context: context,
                builder: (BuildContext context) => _commonHelper!
                    .successBottomSheet("Get Reward Item",
                        "Reward Item order is placed successfully", true));
          }).catchError((onError) {
            _hideProgress();
          });
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    _commonHelper = CommonHelper(context);

    Widget addressDetails() {
      return Container(
        margin: EdgeInsets.only(top: DimensHelper.sidesMargin),
        padding: EdgeInsets.all(DimensHelper.sidesMargin),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.max,
          children: [
            Container(
              alignment: Alignment.centerLeft,
              width: _commonHelper?.screenWidth * .5,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text(
                      (mineUserAddress != null &&
                              mineUserAddress['name'] != null)
                          ? mineUserAddress['name']
                          : "",
                      textAlign: TextAlign.left,
                      style: TextStyle(
                          fontWeight: FontWeight.w500,
                          color: SoloColor.black,
                          fontSize: Constants.FONT_APP_TITLE)),
                  Padding(
                    padding: EdgeInsets.only(top: DimensHelper.sidesMargin),
                    child: Text(
                        (mineUserAddress != null &&
                                mineUserAddress['street'] != null &&
                                mineUserAddress['city'] != null &&
                                mineUserAddress['state'] != null)
                            ? mineUserAddress['street'] +
                                " " +
                                mineUserAddress['city'] +
                                " " +
                                mineUserAddress['state']
                            : "",
                        textAlign: TextAlign.left,
                        style: TextStyle(
                            fontWeight: FontWeight.normal,
                            color: SoloColor.spanishGray,
                            fontSize: Constants.FONT_MEDIUM)),
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: DimensHelper.smallSides),
                    child: Text(
                        (mineUserAddress != null &&
                                mineUserAddress['phoneNumber'] != null)
                            ? "Phone Number: " +
                                mineUserAddress['phoneNumber']
                                    .replaceAll("+1", "")
                            : "",
                        textAlign: TextAlign.left,
                        style: TextStyle(
                            fontWeight: FontWeight.normal,
                            color: SoloColor.spanishGray,
                            fontSize: Constants.FONT_MEDIUM)),
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: DimensHelper.smallSides),
                    child: Text(
                        (mineUserAddress != null &&
                                mineUserAddress['email'] != null)
                            ? "Email: " + mineUserAddress['email']
                            : "",
                        textAlign: TextAlign.left,
                        style: TextStyle(
                            fontWeight: FontWeight.normal,
                            color: SoloColor.spanishGray,
                            fontSize: Constants.FONT_MEDIUM)),
                  )
                ],
              ),
            ),
            GestureDetector(
              onTap: () {
                Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => EditRewardAddress()))
                    .then((value) {
                  PrefHelper.getUserAddress().then((onValue) {
                    setState(() {
                      var address = json.decode(onValue.toString());

                      mineUserAddress = address;
                    });
                  });
                });
              },
              child: Container(
                margin: EdgeInsets.only(left: DimensHelper.halfSides),
                height: 35,
                width: _commonHelper?.screenWidth * .35,
                padding: EdgeInsets.only(
                    left: DimensHelper.sidesMargin,
                    right: DimensHelper.sidesMargin),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                        Radius.circular(DimensHelper.smallSides)),
                    color: SoloColor.pink,
                    boxShadow: [
                      BoxShadow(
                        color: SoloColor.black,
                        blurRadius: 2.0,
                      )
                    ]),
                child: Center(
                  child: Text(
                      (mineUserAddress != null &&
                              mineUserAddress['name'] != null)
                          ? "Edit Address".toUpperCase()
                          : "Add Address".toUpperCase(),
                      style: TextStyle(
                          fontSize: Constants.FONT_LOW,
                          color: SoloColor.white)),
                ),
              ),
            )
          ],
        ),
      );
    }

    Widget divider() {
      return Container(
        margin: EdgeInsets.only(
            left: DimensHelper.sidesMargin, right: DimensHelper.sidesMargin),
        child: Divider(
          height: 1,
          color: SoloColor.spanishGray,
        ),
      );
    }

    Widget selectedItemDetails() {
      return Container(
        margin: EdgeInsets.only(
            left: DimensHelper.sidesMargin, right: DimensHelper.sidesMargin),
        width: _commonHelper?.screenWidth,
        padding: EdgeInsets.all(DimensHelper.sidesMargin),
        child: Row(
          mainAxisSize: MainAxisSize.max,
          children: [
            Container(
              alignment: Alignment.centerLeft,
              width: _commonHelper?.screenWidth * .4,
              child: RichText(
                textAlign: TextAlign.center,
                text: TextSpan(
                  children: [
                    WidgetSpan(
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          CachedNetworkImage(
                            imageUrl: widget.rewardItemDetails!.icon.toString(),
                            height: 30,
                            width: 30,
                            fit: BoxFit.cover,
                            placeholder: (context, url) =>
                                CircularProgressIndicator(),
                            errorWidget: (context, url, error) => Image.asset(
                                'images/dummy_profile.png',
                                width: 30,
                                height: 30,
                                fit: BoxFit.cover),
                          ),
                          Container(
                            padding:
                                EdgeInsets.only(left: DimensHelper.halfSides),
                            child: Text(
                                widget.rewardItemDetails!.name.toString(),
                                style: TextStyle(
                                    fontWeight: FontWeight.normal,
                                    color: SoloColor.black,
                                    fontSize: Constants.FONT_TOP)),
                          )
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
            Container(
              alignment: Alignment.centerRight,
              width: _commonHelper?.screenWidth * .4,
              child: RichText(
                textAlign: TextAlign.center,
                text: TextSpan(
                  children: [
                    WidgetSpan(
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Image.asset("assets/images/ic_point_star.png"),
                          Container(
                            padding:
                                EdgeInsets.only(left: DimensHelper.smallSides),
                            child: Text(
                                widget.rewardItemDetails!.pricePoint.toString(),
                                style: TextStyle(
                                    fontWeight: FontWeight.normal,
                                    color: SoloColor.black,
                                    fontSize: Constants.FONT_TOP)),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )
          ],
        ),
      );
    }

    Widget balancePoint() {
      return Container(
        margin: EdgeInsets.all(DimensHelper.sidesMargin),
        height: 130,
        width: _commonHelper?.screenWidth,
        alignment: Alignment.center,
        decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
              colors: <Color>[
                Color(0xFFf5e4f0),
                Color(0xFFe4eff9),
              ],
            ),
            borderRadius:
                BorderRadius.all(Radius.circular(DimensHelper.halfSides))),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text('Balance Points'.toUpperCase(),
                style: TextStyle(
                    fontWeight: FontWeight.w500,
                    color: SoloColor.black,
                    fontSize: Constants.FONT_MAXIMUM)),
            Container(
              margin: EdgeInsets.only(top: DimensHelper.sidesMargin),
              child: RichText(
                textAlign: TextAlign.center,
                text: TextSpan(
                  children: [
                    WidgetSpan(
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Image.asset("assets/images/ic_point_star.png"),
                          Container(
                            padding:
                                EdgeInsets.only(left: DimensHelper.smallSides),
                            child: Text(balancePoints.toString(),
                                style: TextStyle(
                                    fontWeight: FontWeight.normal,
                                    color: SoloColor.black,
                                    fontSize: Constants.FONT_TOP)),
                          )
                        ],
                      ),
                    )
                  ],
                ),
              ),
            )
          ],
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        backgroundColor: SoloColor.blue,
        automaticallyImplyLeading: false,
        title: Stack(
          children: [
            GestureDetector(
              onTap: () {
                _commonHelper?.closeActivity();
              },
              child: Container(
                width: 25,
                height: 25,
                alignment: Alignment.centerLeft,
                child: Image.asset('images/back_arrow.png'),
              ),
            ),
            Container(
              alignment: Alignment.center,
              child: Text('Address'.toUpperCase(),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.white, fontSize: Constants.FONT_APP_TITLE)),
            )
          ],
        ),
      ),
      body: Stack(
        children: [
          ListView(
            children: [
              addressDetails(),
              divider(),
              selectedItemDetails(),
              divider(),
              balancePoint(),
              Container(
                alignment: Alignment.center,
                child: ButtonWidget(
                  height: _commonHelper?.screenHeight,
                  width: _commonHelper?.screenWidth * .7,
                  onPressed: () {
                    FocusScope.of(context).unfocus();

                    _onContinueTap();
                  },
                  btnText: 'CONTINUE',
                ),
              )
            ],
          ),
          Align(
            child:
                ProgressBarIndicator(_commonHelper?.screenSize, _progressShow),
            alignment: FractionalOffset.center,
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
  }
}
