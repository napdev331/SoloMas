import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:solomas/blocs/settings/edit_address_bloc.dart';
import 'package:solomas/helpers/common_helper.dart';
import 'package:solomas/helpers/constants.dart';
import 'package:solomas/helpers/pref_helper.dart';
import 'package:solomas/helpers/progress_indicator.dart';
import 'package:solomas/resources_helper/colors.dart';
import 'package:solomas/resources_helper/dimens.dart';
import 'package:solomas/resources_helper/strings.dart';
import 'package:solomas/widgets/btn_widget.dart';
import 'package:solomas/widgets/text_field_widget.dart';

class EditRewardAddress extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _EditRewardAddressState();
  }
}

class _EditRewardAddressState extends State<EditRewardAddress> {
  CommonHelper? _commonHelper;

  var _emailController = TextEditingController(),
      _stateController = TextEditingController(),
      _phoneController = TextEditingController(),
      _cityController = TextEditingController(),
      _fullNameController = TextEditingController(),
      _streetController = TextEditingController();

  var _emailFocusNode = FocusNode(),
      _stateFocusNode = FocusNode(),
      _phoneFocusNode = FocusNode(),
      _cityFocusNode = FocusNode(),
      _streetFocusNode = FocusNode(),
      _fullNameFocusNode = FocusNode();

  EditAddressBloc? _addressBloc;

  bool _progressShow = false;

  void _showProgress() {
    setState(() {
      _progressShow = true;
    });
  }

  void _hideProgress() {
    setState(() {
      _progressShow = false;
    });
  }

  @override
  void initState() {
    super.initState();

    _addressBloc = EditAddressBloc();
  }

  void _onSaveTap() {
    _commonHelper?.isInternetAvailable().then((available) {
      if (available) {
        _showProgress();

        PrefHelper.getAuthToken().then((authToken) {
          var address = _streetController.text.toString().trim();

          var resBody = {};

          resBody["name"] = _fullNameController.text.toString().trim();

          resBody["street"] = address;

          resBody["state"] = _stateController.text.toString().trim();

          resBody["city"] = _cityController.text.toString().trim();

          resBody["email"] = _emailController.text.toString().trim();

          resBody["phoneNumber"] =
              Constants.COUNTRY_CODE + _phoneController.text.toString().trim();

          var body = json.encode({'address': resBody});

          _addressBloc
              ?.updatePickUpAddress(authToken.toString(), body)
              .then((onValue) {
            _hideProgress();

            PrefHelper.setUserAddress(json.encode(resBody));

            showCupertinoModalPopup(
                context: context,
                builder: (BuildContext context) => _commonHelper!
                    .successBottomSheet(
                        "Address", "Address Update Successfully", true));
          }).catchError((onError) {
            _hideProgress();
          });
        });
      } else {
        _commonHelper?.showAlert(
            StringHelper.noInternetTitle, StringHelper.noInternetMsg);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    _commonHelper = CommonHelper(context);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: SoloColor.blue,
        automaticallyImplyLeading: false,
        title: Stack(
          children: [
            GestureDetector(
              onTap: () {
                _commonHelper?.closeActivity();
              },
              child: Container(
                width: 25,
                height: 25,
                alignment: Alignment.centerLeft,
                child: Image.asset('images/back_arrow.png'),
              ),
            ),
            Container(
              alignment: Alignment.center,
              child: Text('Edit Address'.toUpperCase(),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.white, fontSize: Constants.FONT_APP_TITLE)),
            )
          ],
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.zero,
        child: Stack(
          children: [
            Container(
              alignment: Alignment.center,
              height: _commonHelper?.screenHeight * .9,
              child: ListView(
                physics: NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                children: [
                  StreamBuilder(
                    stream: _addressBloc?.nameStream,
                    builder: (name, snapshot) => Container(
                      margin:
                          EdgeInsets.only(top: DimensHelper.sidesMarginDouble),
                      child: TextFieldWidget(
                          errorText: snapshot.error as String?,
                          onChangedValue: _addressBloc?.nameChanged,
                          tabColor: SoloColor.blue,
                          etBgColor: Color.fromRGBO(246, 252, 254, 100),
                          screenWidth: _commonHelper?.screenWidth,
                          title: 'Name',
                          focusNode: _fullNameFocusNode,
                          maxLines: 1,
                          secondFocus: _emailFocusNode,
                          keyboardType: TextInputType.text,
                          autoFocus: false,
                          iconPath: "assets/images/ic_user.png",
                          inputFormatter: [
                            FilteringTextInputFormatter.allow(
                                RegExp("[a-zA-Z -]")),
                            LengthLimitingTextInputFormatter(30),
                          ],
                          editingController: _fullNameController,
                          inputAction: TextInputAction.next),
                    ),
                  ),
                  StreamBuilder(
                      stream: _addressBloc?.emailStream,
                      builder: (email, snapshot) => TextFieldWidget(
                          errorText: snapshot.error as String?,
                          onChangedValue: _addressBloc?.emailChanged,
                          tabColor: SoloColor.pink,
                          etBgColor: Color.fromRGBO(255, 246, 250, 100),
                          screenWidth: _commonHelper?.screenWidth,
                          title: 'Email',
                          focusNode: _emailFocusNode,
                          secondFocus: _phoneFocusNode,
                          keyboardType: TextInputType.text,
                          inputFormatter: [
                            FilteringTextInputFormatter.deny(RegExp('[\\ ]'))
                          ],
                          autoFocus: false,
                          iconPath: "assets/images/ic_email.png",
                          editingController: _emailController,
                          inputAction: TextInputAction.next)),
                  StreamBuilder(
                      stream: _addressBloc?.phoneStream,
                      builder: (phone, snapshot) => TextFieldWidget(
                          errorText: snapshot.error as String?,
                          onChangedValue: _addressBloc?.phoneChanged,
                          screenWidth: _commonHelper?.screenWidth,
                          title: 'Phone Number',
                          focusNode: _phoneFocusNode,
                          secondFocus: _streetFocusNode,
                          tabColor: SoloColor.mediumSeaGreen,
                          etBgColor: Color.fromRGBO(247, 252, 248, 100),
                          keyboardType: TextInputType.phone,
                          inputFormatter: [
                            FilteringTextInputFormatter.digitsOnly,
                            FilteringTextInputFormatter.deny(RegExp('[\\ ]')),
                            LengthLimitingTextInputFormatter(10)
                          ],
                          autoFocus: false,
                          iconPath: "assets/images/ic_phone.png",
                          editingController: _phoneController,
                          inputAction: TextInputAction.next)),
                  StreamBuilder(
                      stream: _addressBloc?.streetStream,
                      builder: (address, snapshot) => TextFieldWidget(
                          errorText: snapshot.error as String?,
                          onChangedValue: _addressBloc?.addressChanged,
                          tabColor: SoloColor.denimBlue,
                          etBgColor: Color.fromRGBO(245, 247, 250, 100),
                          screenWidth: _commonHelper?.screenWidth,
                          title: 'Street',
                          focusNode: _streetFocusNode,
                          maxLines: 1,
                          secondFocus: _stateFocusNode,
                          keyboardType: TextInputType.text,
                          autoFocus: false,
                          iconPath: "assets/images/ic_location.png",
                          inputFormatter: [
                            FilteringTextInputFormatter.allow(
                                RegExp("[a-zA-Z0-9 -]")),
                            LengthLimitingTextInputFormatter(60),
                          ],
                          editingController: _streetController,
                          inputAction: TextInputAction.next)),
                  StreamBuilder(
                      stream: _addressBloc?.cityStream,
                      builder: (city, snapshot) => TextFieldWidget(
                          errorText: snapshot.error as String?,
                          onChangedValue: _addressBloc?.cityChanged,
                          tabColor: SoloColor.pastelOrange,
                          etBgColor: Color.fromRGBO(255, 252, 248, 100),
                          screenWidth: _commonHelper?.screenWidth,
                          title: 'City',
                          focusNode: _cityFocusNode,
                          secondFocus: _stateFocusNode,
                          maxLines: 1,
                          keyboardType: TextInputType.text,
                          autoFocus: false,
                          iconPath: "assets/images/ic_location.png",
                          inputFormatter: [
                            FilteringTextInputFormatter.allow(
                                RegExp("[a-zA-Z -]")),
                            LengthLimitingTextInputFormatter(20),
                          ],
                          editingController: _cityController,
                          inputAction: TextInputAction.next)),
                  StreamBuilder(
                      stream: _addressBloc?.stateStream,
                      builder: (state, snapshot) => TextFieldWidget(
                          errorText: snapshot.error as String?,
                          onChangedValue: _addressBloc?.stateChanged,
                          tabColor: SoloColor.middleBluePurple,
                          etBgColor: Color.fromRGBO(250, 249, 252, 100),
                          screenWidth: _commonHelper?.screenWidth,
                          title: 'State',
                          focusNode: _stateFocusNode,
                          maxLines: 1,
                          keyboardType: TextInputType.text,
                          autoFocus: false,
                          iconPath: "assets/images/ic_location.png",
                          inputFormatter: [
                            FilteringTextInputFormatter.allow(
                                RegExp("[a-zA-Z -]")),
                            LengthLimitingTextInputFormatter(20),
                          ],
                          editingController: _stateController,
                          inputAction: TextInputAction.done)),
                  StreamBuilder(
                      stream: _addressBloc?.saveCheck,
                      builder: (context, snapshot) => Container(
                            alignment: Alignment.center,
                            child: ButtonWidget(
                              height: _commonHelper?.screenHeight,
                              width: _commonHelper?.screenWidth * .7,
                              onPressed: () {
                                FocusScope.of(context).unfocus();

                                snapshot.hasData
                                    ? _onSaveTap()
                                    : CommonHelper.alertOk(StringHelper.error,
                                        StringHelper.requiredFields);
                              },
                              btnText: 'SAVE',
                            ),
                          )),
                ],
              ),
            ),
            Align(
              child: ProgressBarIndicator(
                  _commonHelper?.screenSize, _progressShow),
              alignment: FractionalOffset.center,
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _addressBloc?.dispose();

    super.dispose();
  }
}
