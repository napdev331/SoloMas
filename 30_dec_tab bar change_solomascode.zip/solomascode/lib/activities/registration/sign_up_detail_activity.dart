import 'dart:collection';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:solomas/blocs/login/login_bloc.dart';
import 'package:solomas/helpers/common_helper.dart';
import 'package:solomas/helpers/progress_indicator.dart';
import 'package:solomas/resources_helper/colors.dart';
import 'package:solomas/resources_helper/dimens.dart';
import 'package:solomas/resources_helper/strings.dart';
import 'package:solomas/widgets/btn_widget.dart';
import 'package:solomas/widgets/text_field_widget.dart';

import 'add_location_activity.dart';

class SignUpDetailActivity extends StatefulWidget {
  final Map<String, dynamic>? socialBody;

  SignUpDetailActivity({this.socialBody});

  @override
  _SignUpDetailActivityState createState() => _SignUpDetailActivityState();
}

class _SignUpDetailActivityState extends State<SignUpDetailActivity> {
  bool _progressShow = false;

  var _ageController = TextEditingController(),
      _referralController = TextEditingController(),
      _addressController = TextEditingController();

  var _referralFocusNode = FocusNode();

  int userAge = 0;

  DateTime selectedDate = DateTime.now();

  CommonHelper? _commonHelper;

  HashMap<String, Object>? locationDetail;

  LoginBloc? _loginBloc;

  void _showProgress() {
    setState(() {
      _progressShow = true;
    });
  }

  void _hideProgress() {
    setState(() {
      _progressShow = false;
    });
  }

  void _hideKeyBoard() {
    FocusScope.of(context).unfocus();
  }

  @override
  void initState() {
    super.initState();

    _loginBloc = LoginBloc();
  }

  Future<Null> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: selectedDate,
        firstDate: DateTime(1900),
        builder: (BuildContext context, Widget? child) {
          return Theme(
            data: ThemeData.light().copyWith(
                primaryColor: SoloColor.blue,
                buttonColor: SoloColor.blue,
                colorScheme: ColorScheme.light(primary: SoloColor.blue),
                buttonTheme:
                    ButtonThemeData(textTheme: ButtonTextTheme.primary),
                accentColor: SoloColor.blue),
            child: child as Widget,
          );
        },
        lastDate: DateTime.now());

    if (picked != null && picked != selectedDate)
      setState(() {
        selectedDate = picked;

        int age = _commonHelper!.calculateAge(selectedDate);

        if (age >= 18) {
          userAge = age;

          _ageController.text = DateFormat('MM/dd/yyyy').format(selectedDate);
        } else {
          _commonHelper?.showAlert("Age", "Your age must be 18+");
        }
      });
  }

  bool checkValues() {
    if (_ageController.text.isEmpty) {
      _commonHelper?.showAlert("Age", "Please enter a valid age");

      return false;
    }

    return true;
  }

  String _addSocialSignUpData() {
    var isFacebookLogin, id;

    if (widget.socialBody?['userType'] == "facebook") {
      id = 'facebookId';

      isFacebookLogin = true;
    } else if (widget.socialBody?['userType'] == "google") {
      id = 'googleId';

      isFacebookLogin = false;
    } else {
      id = 'appleId';

      isFacebookLogin = null;
    }

    var body = json.encode({
      "userType": widget.socialBody?['userType'],
      "fullName": widget.socialBody?['fullName'],
      "email": widget.socialBody?['email'],
      "profilePic": widget.socialBody?['profilePic'],
      "deviceToken": widget.socialBody?['deviceToken'],
      'age': userAge,
      id: isFacebookLogin == null
          ? widget.socialBody!['appleId']
          : isFacebookLogin
              ? widget.socialBody!['facebookId']
              : widget.socialBody?['googleId'] ?? []
    });

    var reqBody = jsonDecode(body);

    if (_addressController.text.toString().isNotEmpty) {
      Map<String, dynamic> locationMap =
          json.decode(locationDetail!['location'].toString());

      reqBody['locationName'] = _addressController.text.toString();

      reqBody['location'] = locationMap;
    }

    if (_referralController.text.trim().toString().isNotEmpty) {
      reqBody["referralCode"] = _referralController.text.trim().toString();
    }

    return jsonEncode(reqBody).toString();
  }

  void _socialLogin() {
    _showProgress();

    _loginBloc
        ?.socialLogin(_commonHelper as CommonHelper, _addSocialSignUpData())
        .then((onSuccess) {
      _hideProgress();
    }).catchError((onError) {
      _hideProgress();
    });
  }

  Map<String, dynamic> _addSignUpData() {
    var isFacebookLogin, id;

    if (widget.socialBody?['userType'] == "facebook") {
      id = 'facebookId';

      isFacebookLogin = true;
    } else if (widget.socialBody?['userType'] == "google") {
      id = 'googleId';

      isFacebookLogin = false;
    } else {
      id = 'appleId';

      isFacebookLogin = null;
    }

    Map<String, dynamic> signUpBody = {
      'fullName': widget.socialBody?['fullName'],
      'email': widget.socialBody?['email'],
      'deviceToken': widget.socialBody?['deviceToken'],
      'userType': widget.socialBody?['userType'],
      'age': userAge,
      "profilePic": widget.socialBody?['profilePic'],
      id: isFacebookLogin == null
          ? widget.socialBody!['appleId']
          : isFacebookLogin
              ? widget.socialBody!['facebookId']
              : widget.socialBody?['googleId']
    };

    if (_addressController.text.toString().isNotEmpty) {
      Map<String, dynamic> locationMap =
          json.decode(locationDetail!['location'].toString());

      signUpBody['locationName'] = _addressController.text.toString();

      signUpBody['location'] = locationMap;
    }

    if (_referralController.text.trim().toString().isNotEmpty) {
      signUpBody["referralCode"] = _referralController.text.trim().toString();
    }

    return signUpBody;
  }

  void _onSignUpButtonTap() {
    if (checkValues()) {
      FocusScope.of(context).unfocus();

      _commonHelper?.isInternetAvailable().then((available) {
        if (available) {
          _socialLogin();
        } else {
          _commonHelper?.showAlert(
              StringHelper.noInternetTitle, StringHelper.noInternetMsg);
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    _commonHelper = CommonHelper(context);

    var appBarContainerHeight = _commonHelper?.screenHeight * 0.1;

    return Scaffold(
      body: SingleChildScrollView(
        child: GestureDetector(
          onTap: () {
            _hideKeyBoard();
          },
          child: Stack(
            children: [
              Container(
                  height: _commonHelper?.screenHeight,
                  width: _commonHelper?.screenWidth,
                  decoration: BoxDecoration(
                      image: DecorationImage(
                          image: ExactAssetImage("images/back_img.png"),
                          fit: BoxFit.cover)),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        margin:
                            EdgeInsets.only(top: appBarContainerHeight * .33),
                        height: _commonHelper?.screenHeight * .15,
                        child: Image(
                            image:
                                ExactAssetImage("assets/images/ic_logo.png")),
                      ),
                      Container(
                        margin: EdgeInsets.only(top: DimensHelper.sidesMargin),
                        child: GestureDetector(
                          onTap: () {
                            _hideKeyBoard();

                            _selectDate(context);
                          },
                          child: AbsorbPointer(
                            child: TextFieldWidget(
                                screenWidth: _commonHelper?.screenWidth,
                                title: 'Your Age',
                                tabColor: SoloColor.middleBluePurple,
                                etBgColor: Color.fromRGBO(250, 249, 252, 100),
                                keyboardType: TextInputType.text,
                                autoFocus: false,
                                iconPath: "assets/images/ic_age.png",
                                editingEnable: true,
                                editingController: _ageController,
                                inputAction: TextInputAction.done),
                          ),
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          _hideKeyBoard();

                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => AddLocationActivity()),
                          ).then((value) {
                            _hideKeyBoard();

                            if (value != null) {
                              locationDetail = value;
                              _addressController.text =
                                  locationDetail!['locationName'].toString();
                            }
                          });
                        },
                        child: AbsorbPointer(
                          child: TextFieldWidget(
                              screenWidth: _commonHelper?.screenWidth,
                              title: 'Location',
                              tabColor: SoloColor.denimBlue,
                              etBgColor: Color.fromRGBO(245, 247, 250, 100),
                              iconPath: "assets/images/ic_location.png",
                              keyboardType: TextInputType.text,
                              autoFocus: false,
                              maxLines: 2,
                              editingController: _addressController,
                              inputAction: TextInputAction.done,
                              marginTop: DimensHelper.sidesMargin),
                        ),
                      ),
                      TextFieldWidget(
                          screenWidth: _commonHelper?.screenWidth,
                          title: 'Referral Code (Optional)',
                          focusNode: _referralFocusNode,
                          tabColor: SoloColor.pink,
                          etBgColor: Color.fromRGBO(255, 246, 250, 100),
                          keyboardType: TextInputType.text,
                          autoFocus: false,
                          inputFormatter: [
                            FilteringTextInputFormatter.deny(RegExp('[\\ ]'))
                          ],
                          iconPath: "assets/images/ic_referral.png",
                          editingController: _referralController,
                          inputAction: TextInputAction.done),
                      Container(
                        margin: EdgeInsets.only(top: DimensHelper.sidesMargin),
                        alignment: Alignment.center,
                        child: ButtonWidget(
                          height: _commonHelper?.screenHeight,
                          width: _commonHelper?.screenWidth * .7,
                          onPressed: () {
                            _hideKeyBoard();

                            _onSignUpButtonTap();
                          },
                          btnText: 'SUBMIT',
                        ),
                      )
                    ],
                  )),
              Align(
                  child: Container(
                alignment: Alignment.bottomLeft,
                padding: EdgeInsets.only(
                    top: appBarContainerHeight * .5,
                    left: _commonHelper?.screenWidth * .07),
                child: InkWell(
                    onTap: () {
                      _commonHelper?.closeActivity();
                    },
                    child: Container(
                      padding: EdgeInsets.all(DimensHelper.smallSides),
                      child: Image.asset('images/blackarrow_black.png',
                          height: appBarContainerHeight * .33,
                          width: _commonHelper?.screenWidth * .07),
                    )),
              )),
              Align(
                child: ProgressBarIndicator(
                    _commonHelper?.screenSize, _progressShow),
                alignment: FractionalOffset.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
