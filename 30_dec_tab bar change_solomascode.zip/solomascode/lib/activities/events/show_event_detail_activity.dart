import 'package:flutter/cupertino.dart';

class ShowEventDetailActivity extends StatefulWidget {
  const ShowEventDetailActivity({key}) : super(key: key);

  @override
  _ShowEventDetailActivityState createState() => _ShowEventDetailActivityState();
}

class _ShowEventDetailActivityState extends State<ShowEventDetailActivity> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
