import 'package:flutter/material.dart';

class UndefinedScreen extends StatelessWidget {
  static const routeName = '/undefined';
  const UndefinedScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text('Route is not defined'),
      ),
    );
  }
}
