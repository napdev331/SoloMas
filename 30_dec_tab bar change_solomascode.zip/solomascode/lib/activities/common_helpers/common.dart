import 'package:flutter/material.dart';

var scaffoldKey = GlobalKey<ScaffoldState>();
