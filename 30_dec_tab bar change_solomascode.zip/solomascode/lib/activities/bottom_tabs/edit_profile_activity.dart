import 'dart:collection';
import 'dart:convert';
import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:solomas/activities/registration/add_location_activity.dart';
import 'package:solomas/blocs/home/update_user_bloc.dart';
import 'package:solomas/helpers/api_helper.dart';
import 'package:solomas/helpers/common_helper.dart';
import 'package:solomas/helpers/constants.dart';
import 'package:solomas/helpers/pref_helper.dart';
import 'package:solomas/helpers/progress_indicator.dart';
import 'package:solomas/model/upload_image_model.dart';
import 'package:solomas/model/user_profile_model.dart';
import 'package:solomas/resources_helper/colors.dart';
import 'package:solomas/resources_helper/dimens.dart';
import 'package:solomas/resources_helper/strings.dart';
import 'package:solomas/widgets/btn_widget.dart';
import 'package:solomas/widgets/text_field_widget.dart';

import '../common_helpers/app_bar.dart';

class EditProfileActivity extends StatefulWidget {
  final Response? userResponse;

  EditProfileActivity({this.userResponse});

  @override
  State<StatefulWidget> createState() {
    return _EditProfileState();
  }
}

class _EditProfileState extends State<EditProfileActivity> {
  CommonHelper? _commonHelper;

  bool _progressShow = false, refreshData = false;

  File? _profileImage;

  String? authToken, profilePicUrl = "", mineUserName = "";

  HashMap<String, Object> locationDetail = HashMap();

  int? userAge, _radioValue = 0;

  DateTime selectedDate = DateTime.now();

  var _nameController = TextEditingController(),
      _ageController = TextEditingController(),
      _addressController = TextEditingController();

  var _nameFocusNode = FocusNode();

  ApiHelper? _apiHelper;

  UpdateUserBloc? _updateUserBloc;

  ImagePicker _imagePicker = ImagePicker();

  @override
  void initState() {
    super.initState();

    PrefHelper.getAuthToken().then((onValue) {
      setState(() {
        authToken = onValue;
      });
    });

    profilePicUrl = widget.userResponse?.profilePic;

    _nameController.text = widget.userResponse?.fullName ?? '';

    userAge = widget.userResponse?.age;

    _ageController.text = widget.userResponse!.age.toString();

    _addressController.text = widget.userResponse?.locationName ?? '';

    _radioValue = widget.userResponse?.gender == "male" ? 0 : 1;

    _apiHelper = ApiHelper();

    _updateUserBloc = UpdateUserBloc();
  }

  void _hideKeyBoard() {
    FocusScope.of(context).unfocus();
  }

  Widget femaleCheckBox() {
    return RadioListTile<int>(
      title: Text('Female',
          style: TextStyle(fontSize: 16.0, fontStyle: FontStyle.normal)),
      value: 1,
      activeColor: SoloColor.pink,
      groupValue: _radioValue,
      onChanged: _handleRadioValueChange,
    );
  }

  Widget maleCheckBox() {
    return RadioListTile<int>(
      title: Text('Male',
          style: TextStyle(fontSize: 16.0, fontStyle: FontStyle.normal)),
      value: 0,
      activeColor: SoloColor.pink,
      groupValue: _radioValue,
      onChanged: _handleRadioValueChange,
    );
  }

  void _handleRadioValueChange(int? value) {
    setState(() {
      _radioValue = value;
    });
  }

  void _showProgress() {
    setState(() {
      _progressShow = true;
    });
  }

  void _hideProgress() {
    setState(() {
      _progressShow = false;
    });
  }

  bool checkValues() {
    if (_nameController.text.isEmpty) {
      _commonHelper?.showAlert("Name", "Name must not be an empty");

      return false;
    } else if (_ageController.text.isEmpty) {
      _commonHelper?.showAlert("Age", "Please enter a valid age");

      return false;
    } else if (_addressController.text.isEmpty) {
      _commonHelper?.showAlert("Address", "Please enter a valid address");

      return false;
    }
    return true;
  }

  Future<Null> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: selectedDate,
        firstDate: DateTime(1900),
        builder: (BuildContext context, Widget? child) {
          return Theme(
            data: ThemeData.light().copyWith(
                primaryColor: SoloColor.blue,
                buttonColor: SoloColor.blue,
                colorScheme: ColorScheme.light(primary: SoloColor.blue),
                buttonTheme:
                    ButtonThemeData(textTheme: ButtonTextTheme.primary),
                accentColor: SoloColor.blue),
            child: child as Widget,
          );
        },
        lastDate: DateTime.now());

    if (picked != null && picked != selectedDate)
      setState(() {
        selectedDate = picked;

        int age = _commonHelper!.calculateAge(selectedDate);

        if (age >= 18) {
          userAge = age;

          _ageController.text = userAge.toString();
        } else {
          _commonHelper?.showAlert("Age", "Your age must be 18+");
        }
      });
  }

  Future<bool> _willPopCallback() async {
    Navigator.pop(context, refreshData);

    return false;
  }

  @override
  Widget build(BuildContext context) {
    _commonHelper = CommonHelper(context);

    void _onUpdateTap(String reqBody) {
      _commonHelper?.isInternetAvailable().then((available) {
        if (available) {
          _showProgress();

          _updateUserBloc
              ?.updateUser(authToken.toString(), reqBody)
              .then((onValue) {
            Map mapData = json.decode(reqBody);

            if (mapData.containsKey("profilePic"))
              PrefHelper.setUserProfilePic(mapData['profilePic']);

            if (mapData.containsKey("age"))
              PrefHelper.setUserAge(mapData['age'].toString());

            if (mapData.containsKey("fullName"))
              PrefHelper.setUserName(mapData['fullName']);

            refreshData = true;
            Navigator.pop(context, mapData);
          }).catchError((onError) {
            _hideProgress();
          });
        } else {
          _commonHelper?.showAlert(
              StringHelper.noInternetTitle, StringHelper.noInternetMsg);
        }
      });
    }

    Future<String?> _asyncInputDialog(
        BuildContext context, bool isAndroid) async {
      return showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('App Permission'),
            content: Container(
                child: isAndroid
                    ? Text("Allow Solomas to take pictures and record video?")
                    : Text(
                        "Allow Solomas to access photos, media and files on your device?")),
            actions: [
              TextButton(
                child: Text('Cancel', style: TextStyle(color: SoloColor.blue)),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
              TextButton(
                child:
                    Text('Settings', style: TextStyle(color: SoloColor.blue)),
                onPressed: () {
                  openAppSettings();

                  Navigator.of(context).pop();
                },
              ),
            ],
          );
        },
      );
    }

    Future<Null> _cropImage(imageFile) async {
      CroppedFile? croppedFile = await ImageCropper().cropImage(
          sourcePath: imageFile.path,
          compressQuality: 30,
          cropStyle: CropStyle.circle,
          aspectRatioPresets: Platform.isAndroid
              ? [CropAspectRatioPreset.square]
              : [CropAspectRatioPreset.square],
          aspectRatio: CropAspectRatio(ratioX: 1, ratioY: 1),
          uiSettings: [
            AndroidUiSettings(
                toolbarTitle: 'Profile Pic',
                toolbarColor: Colors.white,
                showCropGrid: false,
                hideBottomControls: true,
                cropFrameColor: Colors.transparent,
                toolbarWidgetColor: SoloColor.blue,
                initAspectRatio: CropAspectRatioPreset.original,
                lockAspectRatio: true),
            IOSUiSettings(
              rotateButtonsHidden: true,
              minimumAspectRatio: 1.0,
            )
          ]);

      if (croppedFile != null) {
        imageFile = File(croppedFile.path);

        _showProgress();

        _apiHelper?.uploadFile(imageFile).then((onSuccess) {
          _hideProgress();

          UploadImageModel imageModel = onSuccess;

          setState(() {
            profilePicUrl = imageModel.data?.url;
          });
        }).catchError((onError) {
          _hideProgress();
        });
      }
    }

    Future<Null> _pickImage(isCamera) async {
      var pickedFile = isCamera
          ? await _imagePicker.pickImage(source: ImageSource.camera)
          : await _imagePicker.pickImage(source: ImageSource.gallery);

      _profileImage = File(pickedFile!.path);

      if (_profileImage == null) {
        _hideProgress();
      }

      if (_profileImage != null) {
        setState(() {
          _progressShow = false;

          _cropImage(_profileImage);
        });
      }
    }

    Future<void> requestPermission(Permission pPermission, bool status) async {
      var requestPermission = await pPermission.request();

      if (requestPermission.isGranted) {
        //  _progressShow = true;
        _pickImage(status);
      } else if (requestPermission.isDenied) {
        _asyncInputDialog(context, status);
      } else if (requestPermission.isRestricted) {
        _asyncInputDialog(context, status);
      } else if (requestPermission.isPermanentlyDenied) {
        _asyncInputDialog(context, status);
      } else if (requestPermission.isLimited) {
        _asyncInputDialog(context, status);
      }
    }

    Widget _showGetPictureSheet() {
      return CupertinoActionSheet(
        actions: [
          CupertinoActionSheetAction(
            child: Text("Camera",
                style: TextStyle(
                    color: SoloColor.black,
                    fontSize: Constants.FONT_TOP,
                    fontWeight: FontWeight.w500)),
            onPressed: () {
              Navigator.pop(context);

              setState(() {
                requestPermission(Permission.camera, true);
              });
            },
          ),
          CupertinoActionSheetAction(
            child: Text(
              "Gallery",
              style: TextStyle(
                  color: SoloColor.black,
                  fontSize: Constants.FONT_TOP,
                  fontWeight: FontWeight.w500),
            ),
            onPressed: () {
              Navigator.pop(context);

              setState(() {
                (Platform.isAndroid)
                    ? requestPermission(Permission.storage, false)
                    : requestPermission(Permission.photos, false);
              });
            },
          ),
        ],
        cancelButton: CupertinoActionSheetAction(
          child: Text("Cancel",
              style: TextStyle(
                  color: SoloColor.black,
                  fontSize: Constants.FONT_TOP,
                  fontWeight: FontWeight.w500)),
          isDefaultAction: true,
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      );
    }

    Widget profileImage() {
      return Container(
        alignment: Alignment.topCenter,
        height: _commonHelper?.screenHeight * .18,
        width: _commonHelper?.screenHeight * .18,
        child: Stack(
          alignment: Alignment.center,
          children: [
            Align(
              alignment: Alignment.center,
              child: ClipOval(
                  child: CachedNetworkImage(
                fit: BoxFit.cover,
                height: _commonHelper?.screenHeight * .15,
                width: _commonHelper?.screenHeight * .15,
                imageUrl: profilePicUrl.toString(),
                errorWidget: (context, url, error) => Image.asset(
                  'images/dummy_profile.png',
                  width: _commonHelper?.screenHeight * .15,
                  height: _commonHelper?.screenHeight * .15,
                  fit: BoxFit.cover,
                ),
              )),
            ),
            GestureDetector(
              onTap: () {
                showCupertinoModalPopup(
                    context: context,
                    builder: (BuildContext context) => _showGetPictureSheet());
              },
              child: Align(
                child: Container(
                    margin: EdgeInsets.only(
                        left: _commonHelper?.screenHeight * .15),
                    height: 40,
                    width: 40,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.all(
                            Radius.circular(DimensHelper.sidesMarginDouble)),
                        color: SoloColor.black),
                    child: Image.asset('images/ic_camera_white.png')),
              ),
            ),
          ],
        ),
      );
    }

    void _onContinueTap() {
      var location = json.encode({
        'lat': widget.userResponse?.location?.lat,
        'lng': widget.userResponse?.location?.lng
      });

      Map<String, dynamic> locationMap;

      if (locationDetail.containsKey("location"))
        locationMap = json.decode(locationDetail['location'].toString());
      else
        locationMap = json.decode(location);

      var body = json.encode({
        "profilePic": profilePicUrl,
        "fullName": _nameController.text.trim().toString(),
        'age': userAge,
        'gender': _radioValue == 1 ? "female" : "male",
        "locationName": _addressController.text.trim().toString(),
        "location": locationMap
      });

      _onUpdateTap(body);
    }

    return WillPopScope(
      onWillPop: _willPopCallback,
      child: Scaffold(
        appBar: PreferredSize(
          preferredSize: const Size.fromHeight(80),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 32),
            child: appBar(context),
          ),
        ),
        body: Stack(
          children: [
            Container(
              margin: EdgeInsets.only(top: DimensHelper.sidesMarginDouble),
              alignment: Alignment.center,
              child: ListView(
                padding: EdgeInsets.only(
                    top: DimensHelper.sidesMargin,
                    bottom: DimensHelper.sidesMargin),
                children: [
                  profileImage(),
                  Container(
                    margin:
                        EdgeInsets.only(top: DimensHelper.sidesMarginDouble),
                    child: TextFieldWidget(
                        tabColor: SoloColor.blue,
                        etBgColor: Color.fromRGBO(246, 252, 254, 100),
                        screenWidth: _commonHelper?.screenWidth,
                        title: 'Full Name',
                        focusNode: _nameFocusNode,
                        maxLines: 1,
                        keyboardType: TextInputType.text,
                        autoFocus: false,
                        iconPath: "assets/images/ic_user.png",
                        inputFormatter: [
                          FilteringTextInputFormatter.allow(
                              RegExp("[a-zA-Z -]")),
                          LengthLimitingTextInputFormatter(30),
                        ],
                        editingController: _nameController,
                        inputAction: TextInputAction.next),
                  ),
                  GestureDetector(
                    onTap: () {
                      _hideKeyBoard();

                      _selectDate(context);
                    },
                    child: AbsorbPointer(
                      child: TextFieldWidget(
                          screenWidth: _commonHelper?.screenWidth,
                          title: 'Your Age',
                          tabColor: SoloColor.middleBluePurple,
                          etBgColor: Color.fromRGBO(250, 249, 252, 100),
                          keyboardType: TextInputType.text,
                          autoFocus: false,
                          iconPath: "assets/images/ic_age.png",
                          editingController: _ageController,
                          inputAction: TextInputAction.done),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      _hideKeyBoard();

                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => AddLocationActivity()),
                      ).then((value) {
                        _hideKeyBoard();

                        if (value != null) {
                          locationDetail = value;

                          _addressController.text =
                              locationDetail['locationName'].toString();
                        }
                      });
                    },
                    child: AbsorbPointer(
                      child: TextFieldWidget(
                          screenWidth: _commonHelper?.screenWidth,
                          title: 'Location',
                          tabColor: SoloColor.denimBlue,
                          etBgColor: Color.fromRGBO(245, 247, 250, 100),
                          keyboardType: TextInputType.text,
                          autoFocus: false,
                          maxLines: 2,
                          iconPath: "assets/images/ic_location.png",
                          editingController: _addressController,
                          inputAction: TextInputAction.done),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: DimensHelper.sidesMargin),
                    height: _commonHelper?.screenHeight * .05,
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Expanded(
                          child: maleCheckBox(),
                        ),
                        Expanded(
                          child: femaleCheckBox(),
                        )
                      ],
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: DimensHelper.sidesMargin),
                    alignment: Alignment.center,
                    child: ButtonWidget(
                      height: _commonHelper?.screenHeight,
                      width: _commonHelper?.screenWidth * .7,
                      onPressed: () {
                        _hideKeyBoard();

                        if (checkValues()) {
                          _onContinueTap();
                        }
                      },
                      btnText: 'CONTINUE',
                    ),
                  )
                ],
              ),
            ),
            Align(
              child: ProgressBarIndicator(
                  _commonHelper?.screenSize, _progressShow),
              alignment: FractionalOffset.center,
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _updateUserBloc?.dispose();

    super.dispose();
  }

  Widget appBar(BuildContext context) {
    return SoloAppBar(
      appBarType: StringHelper.backWithText,
      appbarTitle: StringHelper.editProfile,
      backOnTap: () {
        Navigator.pop(context);
      },
    );
  }
}
