import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:solomas/activities/chat/chat_activity.dart';
import 'package:solomas/activities/home/user_profile_activity.dart';
import 'package:solomas/helpers/api_helper.dart';
import 'package:solomas/helpers/common_helper.dart';
import 'package:solomas/helpers/constants.dart';
import 'package:solomas/helpers/pref_helper.dart';
import 'package:solomas/helpers/progress_indicator.dart';
import 'package:solomas/model/search_user_model.dart';
import 'package:solomas/resources_helper/colors.dart';
import 'package:solomas/resources_helper/dimens.dart';
import 'package:solomas/resources_helper/strings.dart';

import '../../resources_helper/images.dart';
import '../../resources_helper/text_styles.dart';
import '../common_helpers/app_bar.dart';

class SearchPeopleActivity extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _SearchPeopleState();
  }
}

class _SearchPeopleState extends State<SearchPeopleActivity> {
//============================================================
// ** Properties **
//============================================================

  var _progressShow = false, showWarning = false;
  var _searchController = TextEditingController();
  List<Data> _aList = [];
  CommonHelper? _commonHelper;
  ApiHelper? _apiHelper;
  String? authToken;

//============================================================
// ** Flutter Build Cycle **
//============================================================

  @override
  void initState() {
    super.initState();

    PrefHelper.getAuthToken().then((onValue) {
      authToken = onValue;
    });

    _apiHelper = ApiHelper();
  }

  @override
  Widget build(BuildContext context) {
    _commonHelper = CommonHelper(context);

    // Widget searchBar() {
    //   return Container(
    //     margin: EdgeInsets.only(
    //         left: DimensHelper.sidesMargin,
    //         right: DimensHelper.sidesMargin,
    //         top: DimensHelper.sidesMargin),
    //     child: Card(
    //       shape: RoundedRectangleBorder(
    //           borderRadius: BorderRadius.all(
    //               Radius.circular(DimensHelper.sidesMarginDouble))),
    //       child: Row(
    //         children: [
    //           Expanded(
    //               child: Container(
    //             padding: EdgeInsets.all(DimensHelper.searchBarMargin),
    //             margin: EdgeInsets.only(left: DimensHelper.sidesMargin),
    //             child: TextFormField(
    //               onFieldSubmitted: (value) {
    //                 _getSearchedUser(value);
    //               },
    //               keyboardType: TextInputType.text,
    //               textInputAction: TextInputAction.search,
    //               maxLines: 1,
    //               minLines: 1,
    //               autofocus: true,
    //               controller: _searchController,
    //               inputFormatters: [
    //                 FilteringTextInputFormatter.allow(RegExp("[a-zA-Z -]")),
    //                 LengthLimitingTextInputFormatter(30),
    //               ],
    //               decoration: InputDecoration.collapsed(
    //                   hintText: 'Search here...',
    //                   hintStyle: TextStyle(
    //                     fontSize: Constants.FONT_MEDIUM,
    //                   )),
    //             ),
    //           )),
    //           Container(
    //             padding: EdgeInsets.only(
    //               left: DimensHelper.halfSides,
    //               right: DimensHelper.sidesMargin,
    //             ),
    //             child: Image.asset(
    //               'images/ic_lg_bag.png',
    //               height: 20,
    //               width: 20,
    //             ),
    //           ),
    //         ],
    //       ),
    //     ),
    //   );
    // }

    /*PreferredSizeWidget topAppBar() {
      return PreferredSize(
        child: Container(
            decoration: BoxDecoration(color: SoloColor.blue),
            child: ListView(
              physics: NeverScrollableScrollPhysics(),
              children: [],
            )),
        preferredSize: Size(_commonHelper?.screenWidth, 120),
      );
    }*/

    /*Widget profileImage(int index) {
      return GestureDetector(
        onTap: () {
          _commonHelper?.startActivity(
              UserProfileActivity(userId: _aList[index].userId.toString()));
        },
        child: ClipOval(
            child: CachedNetworkImage(
          imageUrl: _aList[index].profilePic.toString(),
          height: 70,
          width: 70,
          fit: BoxFit.cover,
          placeholder: (context, url) => CircularProgressIndicator(),
          errorWidget: (context, url, error) => Image.asset(
            'images/dummy_profile.png',
            width: 70,
            height: 70,
            fit: BoxFit.cover,
          ),
        )),
      );
    }*/

    return SafeArea(
      child: Scaffold(
        appBar: PreferredSize(
          preferredSize: const Size.fromHeight(60),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 15),
            child: _appBar(context),
          ),
        ),
        body: Stack(
          children: [
            Container(
              height: _commonHelper?.screenHeight,
              width: _commonHelper?.screenWidth,
              margin: EdgeInsets.only(top: DimensHelper.sidesMargin),
              child: ListView.builder(
                  itemCount: _aList.length,
                  itemBuilder: (BuildContext context, int index) {
                    return peopleDetailCard(index);
                  }),
            ),
            _noUserWarning(),
            Align(
              child: ProgressBarIndicator(
                  _commonHelper?.screenSize, _progressShow),
              alignment: FractionalOffset.center,
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _searchController.clear();

    super.dispose();
  }

//============================================================
// ** Main Widgets **
//============================================================

  Widget _appBar(BuildContext context) {
    return SoloAppBar(
      appBarType: StringHelper.searchBarWithBackNavigation,
      appbarTitle: StringHelper.blockUser,
      hintText: "Search People here...",
      backOnTap: () {
        Navigator.pop(context);
      },
      onSearchBarTextChanged: (v) {},
      onFieldSubmitted: (v) {
        _getSearchedUser(v);
      },
    );
  }

//============================================================
// ** Helper Widgets **
//============================================================

  Widget _noUserWarning() {
    return Visibility(
      visible: showWarning,
      child: Container(
          color: Colors.white,
          alignment: Alignment.center,
          padding: EdgeInsets.all(DimensHelper.btnTopMargin),
          child: Text("No user found",
              style: TextStyle(
                  fontSize: Constants.FONT_TOP,
                  fontWeight: FontWeight.normal,
                  color: SoloColor.spanishGray))),
    );
  }

  Widget userDetails(int index) {
    return Padding(
      padding: EdgeInsets.only(top: _commonHelper?.screenHeight * 0.01),
      child: Container(
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5), color: Colors.white),
        child: Container(
          decoration: BoxDecoration(
              color: SoloColor.lightYellow,
              borderRadius: BorderRadius.circular(18),
              border:
                  Border.all(color: SoloColor.graniteGray.withOpacity(0.2))),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    GestureDetector(
                      onTap: () {
                        _commonHelper?.startActivity(UserProfileActivity(
                            userId: _aList[index].userId.toString()));
                      },
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(50),
                        child: CachedNetworkImage(
                          imageUrl: _aList[index].profilePic.toString(),
                          height: 48,
                          width: 48,
                          fit: BoxFit.cover,
                          placeholder: (context, url) =>
                              CircularProgressIndicator(),
                          errorWidget: (context, url, error) => ClipRRect(
                            borderRadius: BorderRadius.circular(18),
                            child: Image.asset('images/dummy_profile.png',
                                height: 48, width: 48, fit: BoxFit.cover),
                          ),
                        ),
                      ),
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 120,
                          padding:
                              EdgeInsets.only(left: DimensHelper.halfSides),
                          child: Text(_aList[index].fullName!.toUpperCase(),
                              style: SoloStyle.blackLower),
                        ),
                        Container(
                          child: Padding(
                            padding: const EdgeInsets.only(left: 5, top: 2),
                            child: Image.asset("assets/images/ic_band_user.png",
                                height: 20),
                          ),
                        )
                      ],
                    )
                  ],
                ),
                Row(
                  children: [
                    GestureDetector(
                      onTap: () {
                        _commonHelper?.startActivity(
                          ChatActivity(
                            _aList[index].fullName.toString(),
                            _aList[index].userId.toString(),
                            _aList[index].profilePic.toString(),
                          ),
                        );
                      },
                      child: Padding(
                        padding: const EdgeInsets.only(right: 7),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(right: 3),
                              child: SvgPicture.asset(IconsHelper.message,
                                  width: 22),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget peopleDetailCard(int index) {
    return Container(
      margin: EdgeInsets.only(
        left: DimensHelper.sidesMargin,
        right: DimensHelper.sidesMargin,
      ),
      child: Stack(
        children: [
          Container(
            child: userDetails(index),
          ),
        ],
      ),
    );
  }

//============================================================
// ** Helper Functions **
//============================================================

  void _getSearchedUser(String v) {
    _searchController.text = v;

    if (_searchController.text.toString().trim().isEmpty) {
      return;
    }

    FocusScope.of(context).unfocus();

    _commonHelper?.isInternetAvailable().then((available) {
      if (available) {
        _showProgress();

        _apiHelper
            ?.searchPeoples(
                authToken.toString(), _searchController.text.toString().trim())
            .then((onSuccess) {
          _aList.clear();

          SearchUserModel _searchModel = onSuccess;

          _aList = _searchModel.data ?? [];

          if (_aList.isEmpty) {
            showWarning = true;
          } else {
            showWarning = false;
          }

          _hideProgress();
        }).catchError((onError) {
          _hideProgress();
        });
      } else {
        _commonHelper?.showAlert(
            StringHelper.noInternetTitle, StringHelper.noInternetMsg);
      }
    });
  }

  void _showProgress() {
    setState(() {
      _progressShow = true;
    });
  }

  void _hideProgress() {
    setState(() {
      _progressShow = false;
    });
  }

//============================================================
// ** Firebase Functions **
//============================================================

//============================================================
// ** Helper Class **
//============================================================

}
